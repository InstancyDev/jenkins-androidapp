// Modified by Rakesh on 3rd January 2017
// MobileJSInterface methods which are having double arguments are changed to single arguments

var serverURL = "Remote/SCORM.aspx";
var blnIsErrorDisplayed = false;
var errMsgJVM = "Client browser unable to communicate with server - missing Java Virtual Machine (JVM).\n"
errMsgJVM += "You will need either Sun or Microsoft Java Virtual Machine.\n"
errMsgJVM += "Please contact administrator."

APIAdapter = function() {
    var errMessage;
    var _NoError = 0;
    var errorCode = _NoError;
    var errCodeRS = 1;
    var errCodeLMS = 2;


    APIAdapter.prototype.LMSInitialize = function(value) {
        try {
            debugger;
            var result = "false";

            result = MobileJSInterface.SCORM_LMSInitialize();

            return (result);



        } catch (e)
        {

            alert(e);
        }
    }


    //-------------

    APIAdapter.prototype.Initialize = function(value) {
        try {
            debugger;

            var result = "";
            result = MobileJSInterface.SCORM_LMSInitialize();
            return (result);

        } catch (e) {

            alert(e);
        }
    }


    ///----------------


    APIAdapter.prototype.LMSGetValue = function(name) {
        try {

            debugger;


            var result = MobileJSInterface.SCORM_LMSGetValueWithGetValue(name);

            if (result == "empty")
            {

              result = "";

            }

                return result;

        } catch (e) {
            alert(e);
        }

    }

    //////////////////
    APIAdapter.prototype.GetValue = function(name) {
        try {

            debugger;
            var tracking = 0;
            if (document.getElementById("hdnIsAICC") != null) {
                if (document.getElementById("hdnAICCInfo") != null) {
                    var arrRecs = new Array(9);
                    if (document.getElementById("hdnAICCInfo") != null) {
                        var strVal = document.getElementById("hdnAICCInfo").value;
                        for (var j = 0; j < arrRecs.length; j++) {
                            arrRecs[j] = strVal.split("$")[j];
                        }
                    }
                    switch (name.toLowerCase()) {

                        case "cmi.core.student_id":
                            return arrRecs[0];
                            break;
                        case "cmi.core.student_name":
                            return arrRecs[1];
                            break;
                        case "cmi.core.lesson_status":
                            return arrRecs[2];
                            break;
                        case "cmi.core.lesson_location":
                            return arrRecs[3];
                            break;
                        case "cmi.core.entry":
                            return arrRecs[4];
                            break;
                        case "cmi.core.credit":
                            return arrRecs[5];
                            break;
                        case "cmi.core.score.raw":
                            return arrRecs[6];
                            break;
                        case "cmi.core.total_time":
                            return arrRecs[7];
                            break;
                        case "cmi.suspend_data":
                            return arrRecs[8];
                            break;
                        //jameel
                        case "cmi.core.attempts_left":
                            return arrRecs[9];
                            break;
                        default:
                            break;
                    }
                }
            }
            if (document.getElementById(clientID + "_hdnAllowTracking") != null) {
                if (document.getElementById(clientID + "_hdnAllowTracking").value == "yes") {
                    tracking = 1;
                }
            }
            else {
                tracking = 1;
            }

            if (tracking == 1) {
                var result = RSExecute(serverURL, "LMSGetValue", name);
                if (result == null || result.status == -1) {
                    return APIAdapter.prototype.showRemoteScriptingError("LMS GetValue :: Remote Scripting :: \n" + result.message)
                }
                if (APIAdapter.prototype.CheckForErrors(result.return_value));
                return result.return_value;
            }
            else {
                return "";
            }
        } catch (e) {
           // alert(errMsgJVM);
        }

    }

    //////////////////////


    APIAdapter.prototype.LMSSetValue = function(name, value) {

        try {
                debugger;

                var totalString = name + "#$&" + value
                var result = MobileJSInterface.SCORM_LMSSetValueWithTotalValue(totalString);
                return result;

        } catch (e)
        {
          //  alert(errMsgJVM);
        }
    }

    /////////////////

    APIAdapter.prototype.SetValue = function(name, value) {
        try {

            debugger;
            var tracking = 0;
            if (document.getElementById("hdnIsAICC") != null) {
                if (document.getElementById("hdnAICCInfo") != null) {
                    var arrRecs = new Array(9);
                    if (document.getElementById("hdnAICCInfo") != null) {
                        var strVal = document.getElementById("hdnAICCInfo").value;
                        for (var j = 0; j < arrRecs.length; j++) {
                            arrRecs[j] = strVal.split("$")[j];
                        }
                    }
                    switch (name.toLowerCase()) {

                        case "cmi.core.student_id":
                            arrRecs[0] = value;
                            break;
                        case "cmi.core.student_name":
                            arrRecs[1] = value;
                            break;
                        case "cmi.core.lesson_status":
                            arrRecs[2] = value;
                            break;
                        case "cmi.core.lesson_location":
                            arrRecs[3] = value;
                            break;
                        case "cmi.core.credit":
                            arrRecs[5] = value;
                            break;
                        case "cmi.core.score.raw":
                            arrRecs[6] = value;
                            break;
                        case "cmi.core.session_time":
                            arrRecs[7] = value;
                            break;
                        case "cmi.suspend_data":
                            arrRecs[8] = value;
                            break;
                        default:
                            break;
                    }
                    var strVal = '';
                    strVal += arrRecs[0];
                    for (var j = 1; j < arrRecs.length; j++) {
                        strVal += "$";
                        strVal += arrRecs[j];
                    }
                    document.getElementById("hdnAICCInfo").value = strVal;
                }
            }
            if (document.getElementById(clientID + "_hdnAllowTracking") != null) {
                if (document.getElementById(clientID + "_hdnAllowTracking").value == "yes") {
                    tracking = 1;
                }
            }
            else {
                tracking = 1;
            }
            if (tracking == 1) {
                var result = RSExecute(serverURL, "LMSSetValue", name, value);
                if (result == null || result.status == -1) {
                    return APIAdapter.prototype.showRemoteScriptingError("LMS SetValue :: Remote Scripting :: \n" + result.message)
                }
                return (APIAdapter.prototype.CheckForErrors(result.return_value));
            }
            else {
                return "";
            }
        } catch (e) {
          //  alert(errMsgJVM);
        }
    }
    //////////////////


    APIAdapter.prototype.LMSCommit = function(value) {
        try {
            debugger;
            var tracking = 0;
            if (document.getElementById(clientID + "_hdnAllowTracking") != null) {
                if (document.getElementById(clientID + "_hdnAllowTracking").value == "yes") {
                    tracking = 1;
                }
            }
            else {
                tracking = 1;
            }
            if (document.getElementById("hdnIsAICC") != null) {
                if (aicc_sid != null) {
                    if (aicc_sid.indexOf("preview_") > -1)
                        return "";
                }
            }
            if (tracking == 1) {
                var result = RSExecute(serverURL, "LMSCommit", value);
                if (result == null || result.status == -1) {
                    return APIAdapter.prototype.showRemoteScriptingError("LMS Commit :: Remote Scripting :: \n" + result.message)
                }
                return (APIAdapter.prototype.CheckForErrors(result.return_value));
            }
            else {
                return "";
            }
        } catch (e) {
           // alert(errMsgJVM);
        }
    }

    //////////

    APIAdapter.prototype.Commit = function(value) {
        try {
            debugger;
            var tracking = 0;
            if (document.getElementById(clientID + "_hdnAllowTracking") != null) {
                if (document.getElementById(clientID + "_hdnAllowTracking").value == "yes") {
                    tracking = 1;
                }
            }
            else {
                tracking = 1;
            }
            if (document.getElementById("hdnIsAICC") != null) {
                if (aicc_sid != null) {
                    if (aicc_sid.indexOf("preview_") > -1)
                        return "";
                }
            }
            if (tracking == 1) {
                var result = RSExecute(serverURL, "LMSCommit", value);
                if (result == null || result.status == -1) {
                    return APIAdapter.prototype.showRemoteScriptingError("LMS Commit :: Remote Scripting :: \n" + result.message)
                }
                return (APIAdapter.prototype.CheckForErrors(result.return_value));
            }
            else {
                return "";
            }
        } catch (e) {
           // alert(errMsgJVM);
        }
    }
    //////

    APIAdapter.prototype.LMSFinish = function(value) {
        try {
            debugger;
            var tracking = 0;
            if (document.getElementById(clientID + "_hdnAllowTracking") != null) {
                if (document.getElementById(clientID + "_hdnAllowTracking").value == "yes") {
                    tracking = 1;
                }
            }
            else {
                tracking = 1;
            }
            if (document.getElementById("hdnIsAICC") != null) {
                if (aicc_sid != null) {
                    if (aicc_sid.indexOf("preview_") > -1)
                        return "";
                }
            }
            if (tracking == 1) {
                var result = RSExecute(serverURL, "LMSFinish", value);
                if (result == null || result.status == -1) {
                    return APIAdapter.prototype.showRemoteScriptingError("LMS Finish :: Remote Scripting :: \n" + result.message)
                }
                return (APIAdapter.prototype.CheckForErrors(result.return_value));
            }
            else {
                return "";
            }
        } catch (e) {
           // alert(errMsgJVM);
        }
    }

    ///
    APIAdapter.prototype.Terminate = function(value) {
        try {
            debugger;
            var tracking = 0;
            if (document.getElementById(clientID + "_hdnAllowTracking") != null) {
                if (document.getElementById(clientID + "_hdnAllowTracking").value == "yes") {
                    tracking = 1;
                }
            }
            else {
                tracking = 1;
            }
            if (document.getElementById("hdnIsAICC") != null) {
                if (aicc_sid != null) {
                    if (aicc_sid.indexOf("preview_") > -1)
                        return "";
                }
            }
            if (tracking == 1) {
                var result = RSExecute(serverURL, "LMSFinish", value);
                if (result == null || result.status == -1) {
                    return APIAdapter.prototype.showRemoteScriptingError("LMS Finish :: Remote Scripting :: \n" + result.message)
                }
                return (APIAdapter.prototype.CheckForErrors(result.return_value));
            }
            else {
                return "";
            }
        } catch (e) {
           // alert(errMsgJVM);
        }
    }



    ////

    ///
    APIAdapter.prototype.Finish = function(value) {
        try {
            var tracking = 0;
            if (document.getElementById(clientID + "_hdnAllowTracking") != null) {
                if (document.getElementById(clientID + "_hdnAllowTracking").value == "yes") {
                    tracking = 1;
                }
            }
            else {
                tracking = 1;
            }
            if (document.getElementById("hdnIsAICC") != null) {
                if (aicc_sid != null) {
                    if (aicc_sid.indexOf("preview_") > -1)
                        return "";
                }
            }
            if (tracking == 1) {
                var result = RSExecute(serverURL, "LMSFinish", value);
                if (result == null || result.status == -1) {
                    return APIAdapter.prototype.showRemoteScriptingError("LMS Finish :: Remote Scripting :: \n" + result.message)
                }
                return (APIAdapter.prototype.CheckForErrors(result.return_value));
            }
            else {
                return "";
            }
        } catch (e) {
           // alert(errMsgJVM);
        }
    }



    ////

    APIAdapter.prototype.showRemoteScriptingError = function(message) {
        var remoteError = "The following error was encountered when trying to communicate with LMS Server.\n";
        remoteError += "Please contact your administrator.\n\n";
        remoteError += "____________________________________________________________________\n";
        remoteError += "Error Message.\n";
        remoteError += message;

        errorCode = errCodeRS;
        errMessage = remoteError;


        return false;
    }

    APIAdapter.prototype.CheckForErrors = function(returnValue) {
        if (returnValue.substring(0, 5) == "false") {
            if (!blnIsErrorDisplayed) {
                blnIsErrorDisplayed = true;

                errorCode = errCodeLMS;
                errMessage = returnValue.substring(5);


                return false;
            }
        }
        else {
            errorCode = _NoError;
            errMessage = "";
        }
        return returnValue.toString();
    }

    APIAdapter.prototype.LMSGetLastError = function() {
        debugger;
        try {
                return "";

        } catch (e) {
           // alert(errMsgJVM);
        }
    }

    ////

    APIAdapter.prototype.GetLastError = function() {

        try {

                return "";

        } catch (e) {
           // alert(errMsgJVM);
        }
    }
    ////

    APIAdapter.prototype.LMSGetErrorString = function(errCode) {
        try {
            var tracking = 0;
            if (document.getElementById(clientID + "_hdnAllowTracking") != null) {
                if (document.getElementById(clientID + "_hdnAllowTracking").value == "yes") {
                    tracking = 1;
                }
            }
            else {
                tracking = 1;
            }
            if (tracking == 1) {
                var result = RSExecute(serverURL, "LMSGetErrorString", errCode);
                if (result == null || result.status == -1) {
                    return APIAdapter.prototype.showRemoteScriptingError("LMS GetErrorString :: Remote Scripting :: \n" + result.message)
                }
                return result.return_value;
            }
            else {
                return "";
            }
        } catch (e) {
          //  alert(errMsgJVM);
        }
    }

    ///
    APIAdapter.prototype.GetErrorString = function(errCode) {
        try {
            var tracking = 0;
            if (document.getElementById(clientID + "_hdnAllowTracking") != null) {
                if (document.getElementById(clientID + "_hdnAllowTracking").value == "yes") {
                    tracking = 1;
                }
            }
            else {
                tracking = 1;
            }
            if (tracking == 1) {
                var result = RSExecute(serverURL, "LMSGetErrorString", errCode);
                if (result == null || result.status == -1) {
                    return APIAdapter.prototype.showRemoteScriptingError("LMS GetErrorString :: Remote Scripting :: \n" + result.message)
                }
                return result.return_value;
            }
            else {
                return "";
            }
        } catch (e) {
           // alert(errMsgJVM);
        }
    }
    ///

    APIAdapter.prototype.LMSGetDiagnostic = function(errCode) {
        try {
            var tracking = 0;
            if (document.getElementById(clientID + "_hdnAllowTracking") != null) {
                if (document.getElementById(clientID + "_hdnAllowTracking").value == "yes") {
                    tracking = 1;
                }
            }
            else {
                tracking = 1;
            }
            if (tracking == 1) {
                var result = RSExecute(serverURL, "LMSGetDiagnostic", errCode);
                if (result == null || result.status == -1) {
                    return APIAdapter.prototype.showRemoteScriptingError("LMS GetDiagnostic :: Remote Scripting :: \n" + result.message)
                }
                return result.return_value;
            }
            else {
                return "";
            }
        } catch (e) {
           // alert(errMsgJVM);
        }
    }


    ////

    APIAdapter.prototype.GetDiagnostic = function(errCode) {
        try {
            var tracking = 0;
            if (document.getElementById(clientID + "_hdnAllowTracking") != null) {
                if (document.getElementById(clientID + "_hdnAllowTracking").value == "yes") {
                    tracking = 1;
                }
            }
            else {
                tracking = 1;
            }
            if (tracking == 1) {
                var result = RSExecute(serverURL, "LMSGetDiagnostic", errCode);
                if (result == null || result.status == -1) {
                    return APIAdapter.prototype.showRemoteScriptingError("LMS GetDiagnostic :: Remote Scripting :: \n" + result.message)
                }
                return result.return_value;
            }
            else {
                return "";
            }
        } catch (e) {
           // alert(errMsgJVM);
        }
    }
    ////

    /******************************************For Track****************************************************/
    APIAdapter.prototype.LMSTrackInitialize = function(value, SeqID) {
        try {
            //visitID=document.getElementById("lmsLearnerSessionID").value;
            var tracking = 0;
            if (document.getElementById(clientID + "_hdnAllowTracking") != null) {

                if (document.getElementById(clientID + "_hdnAllowTracking").value == "yes") {
                    tracking = 1;
                }
            }
            else {
                tracking = 1;
            }
            if (tracking == 1) {
                var result = RSExecute(serverURL, "LMSTrackInitialize", "", SeqID);
                if (result == null || result.status == -1) {
                    return APIAdapter.prototype.showRemoteScriptingError("LMS Initialize :: Remote Scripting :: \n" + result.message)
                }
                return (APIAdapter.prototype.CheckForErrors(result.return_value));
            }
            else {
                return "";
            }
        } catch (e) {
           // alert(errMsgJVM);
        }
    }

    APIAdapter.prototype.LMSTrackGetValue = function(name, SeqID) {
        try {
            var tracking = 0;
            /*if(document.getElementById("hdnIsAICC") != null)
            {
            if(document.getElementById("hdnAICCInfo")!= null)
            {
            var arrRecs = new Array(9);
            if(document.getElementById("hdnAICCInfo")!= null)
            {
            var strVal=document.getElementById("hdnAICCInfo").value;
            for(var j=0;j<arrRecs.length;j++)
            {
            arrRecs[j]=strVal.split("$")[j];
            }
            }
            switch(name.toLowerCase())
            {

							case "cmi.core.student_id":
            return arrRecs[0];
            break;
            case "cmi.core.student_name":
            return arrRecs[1];
            break;
            case "cmi.core.lesson_status":
            return arrRecs[2];
            break;
            case "cmi.core.lesson_location":
            //var strVal = arrRecs[3];
            //alert(name + '---' + strLessonLocationVal);
            return strLessonLocationVal;
            //return strVal.split(':')[1];
            break;
            case "cmi.core.entry":
            return arrRecs[4];
            break;
            case "cmi.core.credit":
            return arrRecs[5];
            break;
            case "cmi.core.score.raw":
            return arrRecs[6];
            break;
            case "cmi.core.total_time":
            return arrRecs[7];
            break;
            case "cmi.suspend_data":
            return arrRecs[8];
            break;
            case "instancy.trackbookmark":
            var strVal = arrRecs[3];
            //alert(name + '---' + strVal);
            return strVal.split(':')[0];
            return
            default:
            break;
            }

					}
            }*/
            if (document.getElementById(clientID + "_hdnAllowTracking") != null) {
                if (document.getElementById(clientID + "_hdnAllowTracking").value == "yes") {
                    tracking = 1;
                }
            }
            else {
                tracking = 1;
            }
            if (tracking == 1) {
                var result;
                if (SeqID != null)
                    result = RSExecute(serverURL, "LMSTrackGetValue", name, SeqID);
                else
                    result = RSExecute(serverURL, "LMSTrackGetValue", name, 1);
                if (result == null || result.status == -1) {
                    return APIAdapter.prototype.showRemoteScriptingError("LMS GetValue :: Remote Scripting :: \n" + result.message)
                }
                if (APIAdapter.prototype.CheckForErrors(result.return_value) == "true");
                return result.return_value;
            }
            else {
                return "";
            }
        } catch (e) {
           // alert(errMsgJVM);
        }

    }

    APIAdapter.prototype.LMSTrackSetValue = function(name, value, SequenceNumber) {
        try {
            var tracking = 0;
            if (document.getElementById("hdnIsAICC") != null) {
                if (document.getElementById("hdnAICCInfo") != null) {
                    var arrRecs = new Array(9);
                    if (document.getElementById("hdnAICCInfo") != null) {
                        var strVal = document.getElementById("hdnAICCInfo").value;
                        for (var j = 0; j < arrRecs.length; j++) {
                            arrRecs[j] = strVal.split("$")[j];
                        }
                    }
                    switch (name.toLowerCase()) {

                        case "cmi.core.student_id":
                            arrRecs[0] = value;
                            break;
                        case "cmi.core.student_name":
                            arrRecs[1] = value;
                            break;
                        case "cmi.core.lesson_status":
                            arrRecs[2] = value;
                            break;
                        case "cmi.core.lesson_location":
                            //alert("set lessonlocation");
                            arrRecs[3] = SequenceNumber + ':' + value;
                            break;
                        case "cmi.core.entry":
                            arrRecs[4] = value;
                            break;
                        case "cmi.core.credit":
                            arrRecs[5] = value;
                            break;
                        case "cmi.core.score.raw":
                            arrRecs[6] = value;
                            break;
                        case "cmi.core.session_time":
                            /*if (arrRecs[7]!="")
                            arrRecs[7]=parseInt(arrRecs[7]) + ConvertCMITimeSpanToMS(value);
                            else
                            arrRecs[7]=ConvertCMITimeSpanToMS(value);*/
                            break;
                        case "cmi.suspend_data":
                            arrRecs[8] = value;
                            break;
                        case "instancy.trackbookmark":
                            //alert("set bmrk");
                            arrRecs[3] = SequenceNumber + ':';
                            break;
                        default:
                            break;
                    }
                    var strVal = '';
                    strVal += arrRecs[0];
                    for (var j = 1; j < arrRecs.length; j++) {
                        strVal += "$";
                        strVal += arrRecs[j];
                    }
                    document.getElementById("hdnAICCInfo").value = strVal;

                }
            }
            if (document.getElementById(clientID + "_hdnAllowTracking") != null) {
                if (document.getElementById(clientID + "_hdnAllowTracking").value == "yes") {
                    tracking = 1;
                }
            }
            else {
                tracking = 1;
            }
            if (tracking == 1) {
                var result = RSExecute(serverURL, "LMSTrackSetValue", name, value, SequenceNumber);
                if (result == null || result.status == -1) {
                    return APIAdapter.prototype.showRemoteScriptingError("LMS SetValue :: Remote Scripting :: \n" + result.message)
                }
                return (APIAdapter.prototype.CheckForErrors(result.return_value));
            }
            else {
                return "";
            }
        } catch (e) {
          //  alert(errMsgJVM);
        }
    }

    APIAdapter.prototype.LMSTrackCommit = function(value, SequenceNumber) {
        try {
            var tracking = 0;
            if (document.getElementById(clientID + "_hdnAllowTracking") != null) {
                if (document.getElementById(clientID + "_hdnAllowTracking").value == "yes") {
                    tracking = 1;
                }
            }
            else {
                tracking = 1;
            }
            if (document.getElementById("hdnIsAICC") != null) {
                if (aicc_sid != null) {
                    if (aicc_sid.indexOf("preview_") > -1)
                        return "";
                }
            }
            if (tracking == 1) {

                var result = RSExecute(serverURL, "LMSTrackCommit", value, SequenceNumber);
                if (result == null || result.status == -1) {
                    return APIAdapter.prototype.showRemoteScriptingError("LMS Commit :: Remote Scripting :: \n" + result.message)
                }
                return (APIAdapter.prototype.CheckForErrors(result.return_value));
            }
            else {
                return "";
            }
        } catch (e) {
          //  alert(errMsgJVMe);
        }
    }

    APIAdapter.prototype.LMSTrackFinish = function(value, SequenceNumber, UserID) {
        try {
            var tracking = 0;
            if (document.getElementById(clientID + "_hdnAllowTracking") != null) {
                if (document.getElementById(clientID + "_hdnAllowTracking").value == "yes") {
                    tracking = 1;
                }
            }
            else {
                tracking = 1;
            }
            if (document.getElementById("hdnIsAICC") != null) {
                if (aicc_sid != null) {
                    if (aicc_sid.indexOf("preview_") > -1)
                        return "";
                }
            }
            if (tracking == 1) {

                var result = RSExecute(serverURL, "LMSTrackFinish", value, SequenceNumber);
                if (result == null || result.status == -1) {
                    return APIAdapter.prototype.showRemoteScriptingError("LMS Finish :: Remote Scripting :: \n" + result.message)
                }
                return (APIAdapter.prototype.CheckForErrors(result.return_value));
            }
            else {
                return "";
            }
        } catch (e) {
           // alert(errMsgJVM);
        }
    }

    APIAdapter.prototype.LMSTrackGetLastError = function(SequenceNumber) {
        return errorCode;
    }

    APIAdapter.prototype.LMSTrackGetErrorString = function(errCode, SequenceNumber) {
        return errMessage;
    }

    APIAdapter.prototype.LMSTrackGetDiagnostic = function(UserID, SequenceNumber) {
        return "Diagnosis not supported"
    }

    APIAdapter.prototype.SetTrackStatus = function(value) {
        try {
            var tracking = 0;
            if (document.getElementById(clientID + "_hdnAllowTracking") != null) {
                if (document.getElementById(clientID + "_hdnAllowTracking").value == "yes") {
                    tracking = 1;
                }
            }
            else {
                tracking = 1;
            }
            if (tracking == 1) {
                var result;
                if (document.getElementById("hdnIsAICC") != null) {
                    if (isPostBack == false) {
                        if (document.getElementById("hdnAICCInfo") != null) {
                            var arrRecs = new Array(9);
                            if (document.getElementById("hdnAICCInfo") != null) {
                                var strVal = document.getElementById("hdnAICCInfo").value;
                                for (var j = 0; j < arrRecs.length; j++) {
                                    arrRecs[j] = strVal.split("$")[j];
                                }
                            }
                            result = RSExecute(serverURL, "SetTrackStatus", value, 'true');
                            var retVal = result.return_value; //format:- status|score|session_time
                            //alert(retVal);
                            arrRecs[2] = retVal.split("|")[0];
                            if (arrRecs[6] == "" || arrRecs[6] == "0") {
                                if (retVal.split("|")[1] == '')
                                    arrRecs[6] = '0';
                                else
                                    arrRecs[6] = retVal.split("|")[1];
                            }

                            arrRecs[8] = "";
                            var strVal = '';
                            strVal += arrRecs[0];
                            for (var j = 1; j < arrRecs.length; j++) {
                                strVal += "$";
                                strVal += arrRecs[j];
                            }
                            document.getElementById("hdnAICCInfo").value = strVal;
                            //alert('sid - ' + arrRecs[0] + '\nsname - ' + arrRecs[1] + '\nstatus - ' + arrRecs[2] + '\nbookmark - ' + arrRecs[3] + '\nscore - ' + arrRecs[6] + '\nsessiontime - ' + arrRecs[7] + '\nsuspenddata - ' + arrRecs[8]);
                        }
                    }
                    else {
                        return "";
                    }
                }
                else {
                    result = RSExecute(serverURL, "SetTrackStatus", value, 'false');
                }
                return (APIAdapter.prototype.CheckForErrors(result.return_value));
            }
            else {
                return "";
            }
        } catch (e) {
          //  alert(errMsgJVM);
        }
    }

    APIAdapter.prototype.SetTrackInfo = function(Score, SessionTime, IsScorePassed) {
        try {
            var tracking = 0;
            if (document.getElementById(clientID + "_hdnAllowTracking") != null) {
                if (document.getElementById(clientID + "_hdnAllowTracking").value == "yes") {
                    tracking = 1;
                }
            }
            else {
                tracking = 1;
            }
            if (tracking == 1) {
                if (document.getElementById("hdnIsAICC") != null) {
                    if (document.getElementById("hdnAICCInfo") != null) {
                        var arrRecs = new Array(9);
                        var strVal = document.getElementById("hdnAICCInfo").value;
                        for (var j = 0; j < arrRecs.length; j++) {
                            arrRecs[j] = strVal.split("$")[j];
                        }
                        var result = RSExecute(serverURL, "SetTrackInfo", Score, SessionTime, IsScorePassed);
                        var retValue = result.return_value; //this is of the format:- Score~sessiontime

                        arrRecs[6] = Score;
                        arrRecs[7] = SessionTime;
                        var strVal = '';
                        strVal += arrRecs[0];
                        for (var j = 1; j < arrRecs.length; j++) {
                            strVal += "$";
                            strVal += arrRecs[j];
                        }
                        document.getElementById("hdnAICCInfo").value = strVal;
                        return "";
                    }
                }
                else {
                    var result = RSExecute(serverURL, "SetTrackInfo", Score, SessionTime, IsScorePassed);
                    //result.return_value;//this is of the format:- Score~sessiontime
                    return (APIAdapter.prototype.CheckForErrors(result.return_value));
                }
            }
            else {
                return "";
            }
        } catch (e) {

        }
    }

    APIAdapter.prototype.GetStatus = function(value) {
        try {
            var tracking = 0;
            if (document.getElementById(clientID + "_hdnAllowTracking") != null) {
                if (document.getElementById(clientID + "_hdnAllowTracking").value == "yes") {
                    tracking = 1;
                }
            }
            else {
                tracking = 1;
            }
            if (tracking == 1) {
                var result = RSExecute(serverURL, "GetStatus", value);
                return (APIAdapter.prototype.CheckForErrors(result.return_value));
            }
            else {
                return "";
            }
        } catch (e) {

        }
    }
    APIAdapter.prototype.GetUrl = function() {
        try {
            var tracking = 0;
            if (document.getElementById(clientID + "_hdnAllowTracking") != null) {
                if (document.getElementById(clientID + "_hdnAllowTracking").value == "yes") {
                    tracking = 1;
                }
            }
            else {
                tracking = 1;
            }
            if (tracking == 1) {
                var result = RSExecute(serverURL, "GetUrl");
                return (APIAdapter.prototype.CheckForErrors(result.return_value));
            }
            else {
                return "";
            }
        } catch (e) {

        }
    }
    /** (4.7 release) Added By Krishna.b for track workflow rules time dely  **/
    APIAdapter.prototype.SetWorkflowSubmittedTime = function (ruleid, stepid, tDelay, SequenceNumber) {
        try {
            var tracking = 0;
            if (document.getElementById(clientID + "_hdnAllowTracking") != null) {
                if (document.getElementById(clientID + "_hdnAllowTracking").value == "yes") {
                    tracking = 1;
                }
            }
            else {
                tracking = 1;
            }
            if (tracking == 1) {
                var result = RSExecute(serverURL, "SetWorkflowSubmittedTime", ruleid, stepid, tDelay, SequenceNumber);
                return (APIAdapter.prototype.CheckForErrors(result.return_value));
            }
            else {
                return "";
            }
        } catch (e) {

        }
    }

    /** (5.5 release)Added by KrishnaB for templet track remedation workflow rules  **/
    APIAdapter.prototype.GetWorkflowTrackTimeElapsedHours = function () {
        try {
            var tracking = 0;
            if (document.getElementById(clientID + "_hdnAllowTracking") != null) {
                if (document.getElementById(clientID + "_hdnAllowTracking").value == "yes") {
                    tracking = 1;
                }
            }
            else {
                tracking = 1;
            }
            if (tracking == 1) {
                var result = RSExecute(serverURL, "GetWorkflowTrackTimeElapsedHours");
                return (APIAdapter.prototype.CheckForErrors(result.return_value));
            }
            else {
                return "";
            }
        } catch (e) {

        }
    }

    /** (5.5 release)Added by KrishnaB for templet track remedation workflow rules  **/
    APIAdapter.prototype.SetWorkflowContentStatus = function (wActionType, wItemStatus, wItemId, wTrackId) {
        try {
            var tracking = 0;
            if (document.getElementById(clientID + "_hdnAllowTracking") != null) {
                if (document.getElementById(clientID + "_hdnAllowTracking").value == "yes") {
                    tracking = 1;
                }
            }
            else {
                tracking = 1;
            }
            if (tracking == 1) {
                var result = RSExecute(serverURL, "SetWorkflowContentStatus", wActionType, wItemStatus, wItemId, wTrackId);
                return (APIAdapter.prototype.CheckForErrors(result.return_value));
            }
            else {
                return "";
            }
        } catch (e) {

        }
    }

    /** (5.5 release)Added by KrishnaB for templet track remedation workflow rules  **/
    APIAdapter.prototype.UpdateTrackWorkflowResults = function (trackID, trackObjSeqId, trackObjState, objWMessage, objRuleId, objStepId) {
        try {
            var tracking = 0;
            if (document.getElementById(clientID + "_hdnAllowTracking") != null) {
                if (document.getElementById(clientID + "_hdnAllowTracking").value == "yes") {
                    tracking = 1;
                }
            }
            else {
                tracking = 1;
            }
            if (tracking == 1) {
                var result = RSExecute(serverURL, "UpdateTemplateTrackWorkflowResults", trackID, trackObjSeqId, trackObjState, objWMessage, objRuleId, objStepId);
                return (APIAdapter.prototype.CheckForErrors(result.return_value));
            }
            else {
                return "";
            }
        } catch (e) {

        }
    }

    /** (5.5 release)Added by KrishnaB for templet track remedation workflow rules  **/
    APIAdapter.prototype.GetTrackWorkflowResults = function (trackID) {
        try {
            var tracking = 0;
            if (document.getElementById(clientID + "_hdnAllowTracking") != null) {
                if (document.getElementById(clientID + "_hdnAllowTracking").value == "yes") {
                    tracking = 1;
                }
            }
            else {
                tracking = 1;
            }
            if (tracking == 1) {
                var result = RSExecute(serverURL, "GetTrackWorkflowResults", trackID);
                return (APIAdapter.prototype.CheckForErrors(result.return_value));
            }
            else {
                return "";
            }
        } catch (e) {

        }
    }

};
